<?php

use Livewire\Volt\Component;

?>

<div>
    
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lms_biologi/resources/views/livewire/admin/quiz/edit.blade.php ENDPATH**/ ?>