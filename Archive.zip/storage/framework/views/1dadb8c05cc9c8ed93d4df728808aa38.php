<?php if($authenticated): ?><?php $__env->startComponent('scribe::components.badges.base', ['colour' => "darkred", 'text' => 'requires authentication']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lms_biologi/vendor/knuckleswtf/scribe/src/../resources/views//components/badges/auth.blade.php ENDPATH**/ ?>