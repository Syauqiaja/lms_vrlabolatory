

<ui-menu-radio-group <?php echo e($attributes); ?> data-flux-menu-radio-group>
    <?php echo e($slot); ?>

</ui-menu-radio-group>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lms_biologi/vendor/livewire/flux/src/../stubs/resources/views/flux/menu/radio/group.blade.php ENDPATH**/ ?>