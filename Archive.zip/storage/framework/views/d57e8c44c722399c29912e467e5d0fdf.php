<?php

use Livewire\Volt\Component;
use App\Models\Activity;
use App\Models\Material;

?>

<div>
    <?php if (isset($component)) { $__componentOriginal283c1c742ec902fc8794bc53d779987d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal283c1c742ec902fc8794bc53d779987d = $attributes; } ?>
<?php $component = App\View\Components\Nav\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Nav\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal1fcd94c76bde66b391f3029abd312154 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1fcd94c76bde66b391f3029abd312154 = $attributes; } ?>
<?php $component = App\View\Components\Nav\BreadcrumbItem::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav.breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Nav\BreadcrumbItem::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Activities','href' => ''.e(route('activity')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1fcd94c76bde66b391f3029abd312154)): ?>
<?php $attributes = $__attributesOriginal1fcd94c76bde66b391f3029abd312154; ?>
<?php unset($__attributesOriginal1fcd94c76bde66b391f3029abd312154); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1fcd94c76bde66b391f3029abd312154)): ?>
<?php $component = $__componentOriginal1fcd94c76bde66b391f3029abd312154; ?>
<?php unset($__componentOriginal1fcd94c76bde66b391f3029abd312154); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal1fcd94c76bde66b391f3029abd312154 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1fcd94c76bde66b391f3029abd312154 = $attributes; } ?>
<?php $component = App\View\Components\Nav\BreadcrumbItem::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav.breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Nav\BreadcrumbItem::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($activity->title).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1fcd94c76bde66b391f3029abd312154)): ?>
<?php $attributes = $__attributesOriginal1fcd94c76bde66b391f3029abd312154; ?>
<?php unset($__attributesOriginal1fcd94c76bde66b391f3029abd312154); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1fcd94c76bde66b391f3029abd312154)): ?>
<?php $component = $__componentOriginal1fcd94c76bde66b391f3029abd312154; ?>
<?php unset($__componentOriginal1fcd94c76bde66b391f3029abd312154); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal283c1c742ec902fc8794bc53d779987d)): ?>
<?php $attributes = $__attributesOriginal283c1c742ec902fc8794bc53d779987d; ?>
<?php unset($__attributesOriginal283c1c742ec902fc8794bc53d779987d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal283c1c742ec902fc8794bc53d779987d)): ?>
<?php $component = $__componentOriginal283c1c742ec902fc8794bc53d779987d; ?>
<?php unset($__componentOriginal283c1c742ec902fc8794bc53d779987d); ?>
<?php endif; ?>

    <div class="flex flex-col sm:flex-row mb-8 w-full">
        <div class="sm:w-1/2 w-full">
            <img src="<?php echo e(Storage::url($activity->image)); ?>" alt="<?php echo e($activity->title); ?>"
                class="object-cover w-full h-full rounded-md">
        </div>
        <div class="flex-1 p-4">
            <div class="font-bold text-lg mb-2">
                <?php echo e($activity->title); ?>

            </div>
            <div>
                <?php echo e($activity->description); ?>

            </div>
        </div>
    </div>

    <div class="flex items-center mb-8">
        <div>
            <span class="font-semibold text-xl block">Daftar Materi</span>
            <span class="text-sm block text-gray-400"><?php echo e($activity->title); ?></span>
        </div>
        <?php if (isset($component)) { $__componentOriginal4a4f7aa062a095c651c2f80bb685a42a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a4f7aa062a095c651c2f80bb685a42a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::spacer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a4f7aa062a095c651c2f80bb685a42a)): ?>
<?php $attributes = $__attributesOriginal4a4f7aa062a095c651c2f80bb685a42a; ?>
<?php unset($__attributesOriginal4a4f7aa062a095c651c2f80bb685a42a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a4f7aa062a095c651c2f80bb685a42a)): ?>
<?php $component = $__componentOriginal4a4f7aa062a095c651c2f80bb685a42a; ?>
<?php unset($__componentOriginal4a4f7aa062a095c651c2f80bb685a42a); ?>
<?php endif; ?>
        <!--[if BLOCK]><![endif]--><?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
        <div class="flex gap-3">
            <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['variant' => 'outline','href' => ''.e(route('admin.material.create', ['activity' => $activity->id])).'','iconTrailing' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'outline','href' => ''.e(route('admin.material.create', ['activity' => $activity->id])).'','iconTrailing' => 'plus']); ?>
                Tambah Materi
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <!-- Search and Filter Bar -->
    <div class="flex flex-col sm:flex-row gap-4 items-start sm:items-center mb-8">
        <!-- Search Input -->
        <div class="flex-1 w-full sm:max-w-md">
            <?php if (isset($component)) { $__componentOriginal26c546557cdc09040c8dd00b2090afd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal26c546557cdc09040c8dd00b2090afd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::input.index','data' => ['wire:model.live.debounce.300ms' => 'search','placeholder' => 'Cari materi...','icon' => 'magnifying-glass']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.live.debounce.300ms' => 'search','placeholder' => 'Cari materi...','icon' => 'magnifying-glass']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal26c546557cdc09040c8dd00b2090afd0)): ?>
<?php $attributes = $__attributesOriginal26c546557cdc09040c8dd00b2090afd0; ?>
<?php unset($__attributesOriginal26c546557cdc09040c8dd00b2090afd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26c546557cdc09040c8dd00b2090afd0)): ?>
<?php $component = $__componentOriginal26c546557cdc09040c8dd00b2090afd0; ?>
<?php unset($__componentOriginal26c546557cdc09040c8dd00b2090afd0); ?>
<?php endif; ?>
        </div>
    </div>

    <div class="grid grid-cols-2 gap-4 items-start sm:items-center mb-8">
        <!--[if BLOCK]><![endif]--><?php for($i = 0; $i < count($materials); $i++): ?> <a
            href="<?php echo e(route('material.detail', ['activity' => $activity->id, 'material' => $materials[$i]->id])); ?>"
            class="col-span-2 md:col-span-1 p-4 border border-gray-300/30 rounded-md flex gap-3 items-center hover:bg-blue-50/10">
            <div class="rounded-full bg-gray-300/50 flex justify-center items-center w-8 h-8 flex-none">
                <span class="font-bold"><?php echo e($materials[$i]->order); ?></span>
            </div>
            <div class="flex-1">
                <div class="text-start font-medium">
                    <?php echo e($materials[$i]->title); ?>

                </div>
            </div>
            </a>
            <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lms_biologi/resources/views/livewire/activity/detail.blade.php ENDPATH**/ ?>