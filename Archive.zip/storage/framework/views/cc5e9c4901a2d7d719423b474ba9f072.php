<?php

use Livewire\Volt\Component;
use App\Models\Quiz;
use App\Models\UserQuestionAnswer;
use App\Models\UserQuizResult;
use Illuminate\Support\Facades\Auth;

?>

<div class="min-h-screen">
    <?php if (isset($component)) { $__componentOriginal283c1c742ec902fc8794bc53d779987d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal283c1c742ec902fc8794bc53d779987d = $attributes; } ?>
<?php $component = App\View\Components\Nav\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Nav\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-6']); ?>
        <?php if (isset($component)) { $__componentOriginal1fcd94c76bde66b391f3029abd312154 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1fcd94c76bde66b391f3029abd312154 = $attributes; } ?>
<?php $component = App\View\Components\Nav\BreadcrumbItem::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav.breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Nav\BreadcrumbItem::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Quiz','href' => ''.e(route('admin.quiz')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1fcd94c76bde66b391f3029abd312154)): ?>
<?php $attributes = $__attributesOriginal1fcd94c76bde66b391f3029abd312154; ?>
<?php unset($__attributesOriginal1fcd94c76bde66b391f3029abd312154); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1fcd94c76bde66b391f3029abd312154)): ?>
<?php $component = $__componentOriginal1fcd94c76bde66b391f3029abd312154; ?>
<?php unset($__componentOriginal1fcd94c76bde66b391f3029abd312154); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal1fcd94c76bde66b391f3029abd312154 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1fcd94c76bde66b391f3029abd312154 = $attributes; } ?>
<?php $component = App\View\Components\Nav\BreadcrumbItem::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav.breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Nav\BreadcrumbItem::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($quiz->title).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1fcd94c76bde66b391f3029abd312154)): ?>
<?php $attributes = $__attributesOriginal1fcd94c76bde66b391f3029abd312154; ?>
<?php unset($__attributesOriginal1fcd94c76bde66b391f3029abd312154); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1fcd94c76bde66b391f3029abd312154)): ?>
<?php $component = $__componentOriginal1fcd94c76bde66b391f3029abd312154; ?>
<?php unset($__componentOriginal1fcd94c76bde66b391f3029abd312154); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal283c1c742ec902fc8794bc53d779987d)): ?>
<?php $attributes = $__attributesOriginal283c1c742ec902fc8794bc53d779987d; ?>
<?php unset($__attributesOriginal283c1c742ec902fc8794bc53d779987d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal283c1c742ec902fc8794bc53d779987d)): ?>
<?php $component = $__componentOriginal283c1c742ec902fc8794bc53d779987d; ?>
<?php unset($__componentOriginal283c1c742ec902fc8794bc53d779987d); ?>
<?php endif; ?>
    <div class="grid grid-cols-3">
        <div class="rounded-lg shadow-md p-5 col-span-3 md:col-span-2">
            <div class="text-center">
                <h1 class="text-3xl font-bold text-gray-900 dark:text-white mb-4"><?php echo e($quiz->title); ?></h1>
    
                <!--[if BLOCK]><![endif]--><?php if($quiz->description): ?>
                <p class="text-gray-600 dark:text-gray-300 mb-8 text-lg"><?php echo e($quiz->description); ?></p>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                <div class="bg-blue-50 dark:bg-gray-500/20 rounded-lg p-6 mb-8">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                        <div class="bg-white dark:bg-gray-500/20 rounded-lg p-4">
                            <div class="text-2xl font-bold text-blue-600"><?php echo e($totalQuestions); ?></div>
                            <div class="text-sm text-gray-600 dark:text-gray-300">Questions</div>
                        </div>
                        <div class="bg-white dark:bg-gray-500/20 rounded-lg p-4">
                            <div class="text-2xl font-bold text-green-600"><?php echo e($quiz->passing_grade); ?>%</div>
                            <div class="text-sm text-gray-600 dark:text-gray-300">Passing Grade</div>
                        </div>
                    </div>
                </div>
    
                <div class="text-left bg-gray-50 dark:bg-gray-500/20 rounded-lg p-6 mb-8">
                    <h3 class="font-semibold text-gray-900 mb-3 dark:text-white">Instructions:</h3>
                    <ul class="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-2">
                        <li>Read each question carefully before selecting your answer</li>
                        <li>You can navigate between questions using the navigation buttons</li>
                        <li>Make sure to answer all questions before submitting</li>
                        <li>You need <?php echo e($quiz->passing_grade); ?>% or higher to pass</li>
                        <li>Once submitted, you cannot change your answers</li>
                    </ul>
                </div>
    
                <a href="<?php echo e(route('quiz.take-quiz' ,['quiz' => $quiz->id])); ?>"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-lg transition duration-300">
                    Start Quiz
                </a>
            </div>
        </div>
        <div class="rounded-lg shadow-md-p-5 col-span-3 md:col-span-1 mt-4">
            <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-4 md:mb-7 text-center">Attempt History</h2>
            <div class="bg-blue-50 dark:bg-gray-500/20 w-full p-3">
                <table class="table-auto w-full text-center">
                    <thead>
                        <tr>
                        <th>Date</th>
                        <th>Score</th>
                        <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php if(!$userAttempts): ?>
                            <tr>
                                <td rowspan="2" class="p-4 text-center">
                                    <span>History empty</span>
                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $userAttempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($attempt->created_at); ?></td>
                                <td><?php echo e($attempt->score); ?></td>
                                <td class="<?php echo e($attempt->score >= ($quiz->passing_grade ?? 0) ? 'text-green-500' : 'text-red-500'); ?>"><?php echo e($attempt->note); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                    </table>
            </div>
        </div>
    </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lms_biologi/resources/views/livewire/admin/quiz/detail.blade.php ENDPATH**/ ?>